<template>
  <div id="sidebar" class="p-5 flex flex-col shrink-0 border-r-2 border-r-gray-200">
    <slot />
  </div>
</template>
<script setup lang="ts"></script>
