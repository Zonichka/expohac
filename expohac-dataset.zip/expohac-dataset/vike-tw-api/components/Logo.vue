<template>
  <div class="p-5 mb-2">
    <a href="/">
      <img src="../assets/logo.svg" height="64" width="64" />
    </a>
  </div>
</template>
<script setup lang="ts"></script>
