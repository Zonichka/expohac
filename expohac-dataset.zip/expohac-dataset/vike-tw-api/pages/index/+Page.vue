<template>
  <WorkDataset />
</template>
<script setup lang="ts">
import WorkDataset from './template/WorkDataset.vue'
</script>
