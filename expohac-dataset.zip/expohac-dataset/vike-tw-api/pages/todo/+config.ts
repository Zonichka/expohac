const config = {
  prerender: false,
};

export default config;
