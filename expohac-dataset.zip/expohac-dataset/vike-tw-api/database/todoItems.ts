interface TodoItem {
  text: string;
}

const todos = {
  todo: [{ text: "Buy milk" }, { text: "Buy strawberries" }],
};

export { todos };
export type { TodoItem };
